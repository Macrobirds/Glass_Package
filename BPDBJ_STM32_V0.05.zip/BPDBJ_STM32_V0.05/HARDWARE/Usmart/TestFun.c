#include "GlobalInclude.h"
#include "TestFun.h"
#include "math.h"
// ��ע����UCOSIIz�У�������Usmart�е���delay_ms()����ΪUsmart���ж���ִ��

void Test_FunID(void(*fun)(void))
{
	fun();
}



// ����������
void flashReadProtect(u8 controlType)
{
	switch(controlType)
	{
		case 0:
			if(FLASH_GetReadOutProtectionStatus() == SET)
				printf("Flash������״̬������\r\n");
			else if(FLASH_GetReadOutProtectionStatus() == RESET)
				printf("Flash������״̬���ر�\r\n");
			break;
		case 1:
			open_FlashReadProtect();
			printf("Flash�����������ɹ�������رձ�����Ҫ����\r\n");
			break;
		case 2:
			LED1 = LED_ON;
			LED2 = LED_ON;
			printf("���ڹر�Flash������������ǰ�ѿ����������Իٳ���\r\n");
			close_FlashReadProtect();	
			break;
	}	
}

void showMachineInfo(void)
{
//	u32 ChipUniqueID[3];
//	//��ַ��С����,�ȷŵ��ֽڣ��ٷŸ��ֽڣ�С��ģʽ
//	//��ַ��С����,�ȷŸ��ֽڣ��ٷŵ��ֽڣ����ģʽ
//	ChipUniqueID[2] = *(__IO u32*)(0X1FFFF7E8);  // ���ֽ�
//	ChipUniqueID[1] = *(__IO u32 *)(0X1FFFF7EC); // 
//	ChipUniqueID[0] = *(__IO u32 *)(0X1FFFF7F0); // ���ֽ� 
	printf("����汾��: %d\r\n", Program_Versions);
	printf("�������к�: %ld\r\n", (long)deviceSnNumber); 
//	printf("�������к�: %ld\r\n", (long)((ChipUniqueID[0] ^ ChipUniqueID[1] ^ ChipUniqueID[2])&0xffffff)); 
}

void writeProgramVersions(u32 serialNumber)
{
	u8 tmpbuf[4];
	tmpbuf[0] = ((u8 *)(&serialNumber))[3];
	tmpbuf[1] = ((u8 *)(&serialNumber))[2];
	tmpbuf[2] = ((u8 *)(&serialNumber))[1];
	tmpbuf[3] = ((u8 *)(&serialNumber))[0];
	writeCiphertext(tmpbuf);
	printf("д�����汾��: %x%x%x%x\r\n", tmpbuf[0], tmpbuf[1], tmpbuf[2], tmpbuf[3]);	
}

void writeMachineId(u32 machineId)
{
	close_FlashReadProtect();	
}

void setDebugState(u8 debugStateNumber, u8 onOff)
{
	switch(debugStateNumber)
	{
		case 1:
			debugState.cpu = (onOff > 0) ? true : false;
			break;
		case 2:
			debugState.position = (onOff > 0) ? true : false;
			break;
		case 3:
			debugState.deviceState = (onOff > 0) ? true : false;
			break;
		case 4:
			debugState.gdState = (onOff > 0) ? true : false;
			break;
		case 5:
			debugState.mpd = (onOff > 0) ? true : false;
			break;
		case 6:
			debugState.motionState = (onOff > 0) ? true : false;
			break;
		

//		case 0:
//			debugState.timer6 = (onOff > 0) ? true : false;
//			debugState.deviceState = (onOff > 0) ? true : false;
//			debugState.temp = (onOff > 0) ? true : false;
//			debugState.motion = (onOff > 0) ? true : false;
//			debugState.step = (onOff > 0) ? true : false;
//			debugState.cpu = (onOff > 0) ? true : false;
//			debugState.position = (onOff > 0) ? true : false;
//			debugState.getStepInfo = (onOff > 0) ? true : false;
//			break;
//		case 1:
//			debugState.timer6 = (onOff > 0) ? true : false;
//			break;
//		case 2:
//			debugState.deviceState = (onOff > 0) ? true : false;
//			break;
//		case 3:
//			debugState.temp = (onOff > 0) ? true : false;
//			if(debugState.temp)
//				softTimer_tempDetection_enable = true;
//			break;
//		case 4:
//			debugState.motion = (onOff > 0) ? true : false;
//			break;
//		case 5:
//			debugState.step = (onOff > 0) ? true : false;
//			break;
//		case 6:
//			debugState.cpu = (onOff > 0) ? true : false;
//			break;
//		case 7:
//			debugState.position = (onOff > 0) ? true : false;
//			break;
//		case 8:
//			debugState.motionState = (onOff > 0) ? true : false;
//			break;
//		case 9:
//			debugState.getStepInfo = (onOff > 0) ? true : false;
//			break;
	}
}

void beep(u8 onOff)
{
	BUZZER = (onOff > 0) ? BUZZER_ON : !BUZZER_ON;
}

void motorReset(void)
{
	deviceState.motorReset_runningState = RunningState_none;
	deviceState.motorReset_threadEnable = ON;
	deviceState.motorReset_runningState = RunningState_readyStart;	
}

void pushinBox(void)
{
	deviceState.pushinBox_runningState = RunningState_none;
	deviceState.pushinBox_threadEnable = ON;	
	deviceState.pushinBox_runningState = RunningState_readyStart;	
//	deviceState.targetSite = targetSite;
}

void pushOutBox(void)
{
	deviceState.pushOutBox_runningState = RunningState_none;
	deviceState.pushOutBox_threadEnable = ON;	
	deviceState.pushOutBox_runningState = RunningState_readyStart;
}
