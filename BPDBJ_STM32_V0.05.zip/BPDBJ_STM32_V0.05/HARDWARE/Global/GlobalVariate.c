#include "GlobalInclude.h"
u8 DeviceType = DeviceType_Default;
u32 deviceSnNumber = 0;
OS_CPU_SR cpu_sr = 0;
bool initState = false;
struct DebugState debugState = {0};
volatile struct DeviceState deviceState = {0};
struct MotorPositionData mpd = {0};
volatile struct HardwareOnOffState hardwareState = {0};
struct ProgramInfo programInfo = {0};
//struct StepInfo stepInfo = {0};
//volatile struct MotorInfo motorInfo_XZ = {0,0,0};
volatile struct MotorInfo motorInfo_X = {0,0,0};
volatile struct MotorInfo motorInfo_Y = {0,0,0};
//volatile struct MotorInfo motorInfo_C = {0,0,0};
//volatile struct MotorInfo motorInfo_D = {0,0,0};
//volatile struct MotorRunParam motorRunParam_XZ = {0,0,0,0,0,0,0,0,0,0,0};
volatile struct MotorRunParam motorRunParam_X = {0,0,0,0,0,0,0,0,0,0,0};
volatile struct MotorRunParam motorRunParam_Y = {0,0,0,0,0,0,0,0,0,0,0};
//volatile struct MotorRunParam motorRunParam_C = {0,0,0,0,0,0,0,0,0,0,0};
//volatile struct MotorRunParam motorRunParam_D = {0,0,0,0,0,0,0,0,0,0,0};

//volatile u8 doorState = 0;
//volatile u8 coverState = 0;

u8 DIR1_FRONT = DIR1_FRONT_Default;
u8 DIR2_FRONT = DIR2_FRONT_Default;
u8 DIR3_FRONT = DIR3_FRONT_Default;
//u8 DIR4_FRONT = DIR4_FRONT_Default;
//u8 DIR5_FRONT = DIR5_FRONT_Default;

//bool Change_Move_Direction_XZ = false;
bool Change_Move_Direction_X = false;
bool Change_Move_Direction_Y = false;

u8 Carrier_Versions_Default = 0;
//bool Enable_Check_G_QLE_IsExist = false;

// ���ڴ�ż���ʱ��ʱ������ֵ
//unsigned short * accPeriodArray_XZ = 0;
unsigned short * accPeriodArray_X = 0;
unsigned short * accPeriodArray_Y = 0;
//unsigned short * accPeriodArray_C = 0;
//unsigned short * accPeriodArray_D = 0;
//struct MixtureData mixtureData_XZ = {0};
struct MixtureData mixtureData_X = {0};
struct MixtureData mixtureData_Y = {0};
volatile u32 nowRtcTime = 0;

//u32 alarmSeccount_suckBottomWait=0;
//u32 alarmSeccount_stepWait=0;
//u32 alarmSeccount_suckTopWait=0;
//u32 alarmSeccount_mixture=0;
//volatile bool alarmEnable_stepWait=0;
//volatile bool alarmEnable_suckBottomWait=0;
//volatile bool alarmEnable_suckTopWait=0;
//volatile bool alarmEnable_mixture=0;
//volatile bool alarmEnable_completeSound=false;			// �������������������

void set_carrierVersions_Default(void)
{
	Carrier_Versions_Default = 0;
	// �ж��豸����
	switch(DeviceType)
	{
		case DeviceType_dbj_zw_bmh:
			Carrier_Versions_Default = BMH;	
			mpd.carriersVersions = BMH;
			break;
		case DeviceType_dbj_zw_bp:
			Carrier_Versions_Default = BP;	
			mpd.carriersVersions = BP;
			break;
		// δ���û��ͣ�ʹ��Ĭ�ϲ���
		case DeviceType_none:
		default:
			break;
	}
}

void set_motorPositionData_Default(void)
{
//	W25QXX_Write(&DeviceType, SpiFlashAddr_DeviceType, 1);
//	delay_ms(20);
	// �ж��豸����
//	switch(DeviceType)
//	{
//		case DeviceType_dbj_zw_bmh:
//		{
//			switch(mpd.carriersVersions)
//			{
//				case BMH:
//					mpd.XZ_1d = 200;							// ��ת�� 1mm������
					mpd.X_1mm = 100;							// ������ 1mm������
					mpd.Y_1mm = 100;							// ������ 1mm������
//					mpd.XZ_accStartFreq = mpd.XZ_1d * 30;				// ��ת�� Ĭ��Ƶ��
					mpd.X_accStartFreq = mpd.X_1mm * 30;				// ������ Ĭ��Ƶ��
					mpd.Y_accStartFreq = mpd.Y_1mm * 30;				// ������ Ĭ��Ƶ��
//					mpd.XZ_accMaxFreq = mpd.XZ_1d * 48;					// ��ת�� ��λƵ��
					mpd.X_accMaxFreq = mpd.X_1mm * 200;					// ������ ��λƵ��
					mpd.Y_accMaxFreq = mpd.Y_1mm * 220;					// ������ ��λƵ�� 
//					mpd.XZ_site_1 = 7500;		// ��ת�� 1��λ ������
//					mpd.XZ_site_2 = 19500;	// ��ת�� 2��λ ������
//					mpd.XZ_site_3 = 31500;	// ��ת�� 3��λ ������
//					mpd.XZ_site_4 = 43500;	// ��ת�� 4��λ ������
//					mpd.XZ_site_5 = 55500;	// ��ת�� 5��λ ������
//					mpd.XZ_site_6 = 67500;	// ��ת�� 6��λ ������
					mpd.X_end = mpd.X_1mm * 82 ;	// ������ ����λ�� ������
					mpd.X_ale = 0;                // ������ �Ѿ������յ��־����XE����1���ص�XH����0
					mpd.Y_end = mpd.Y_1mm * 145 ;	// ������ ����λ�� ������
					mpd.waitTime_boxDown_ms = 200;
//					mpd.XZ_defaultFreq = mpd.XZ_1d * 40;       // ��ת�� Ĭ��Ƶ��
					mpd.X_defaultFreq = mpd.X_1mm * 30;	       // ������ Ĭ��Ƶ��
					mpd.Y_defaultFreq = mpd.Y_1mm * 30;				// ������ Ĭ��Ƶ��
//					break;
//			}
//			break;
//		}
		// δ���û��ͣ�ʹ��Ĭ�ϲ���
//		case DeviceType_none:
//		default:
//			break;
//	}
	W25QXX_Write((u8 *)&mpd, SpiFlashAddr_motorPositionData, sizeof(mpd));
	delay_ms(50);
}

// ���ݻ��͡���װ��ͺ��޸ļ��ȷ�ʽ
void update_globalParam(void)
{
	// Ĭ�ϲ���
//	Change_Move_Direction_XZ = false;
	Change_Move_Direction_X = false;
	Change_Move_Direction_Y = false;
	// �ж��豸����
	switch(DeviceType)
	{
		case DeviceType_dbj_zw_bmh:
		{
			switch(mpd.carriersVersions)
			{
				case BMH:
					break;
			}
			break;
		}
		case DeviceType_dbj_zw_bp:
		{
			switch(mpd.carriersVersions)
			{
				case BP:
					break;
			}
			break;
		}
		// δ���û��ͣ�ʹ��Ĭ�ϲ���
		case DeviceType_none:
		default:
			break;
	}
}

bool check_needRunMotorXThread(void)
{
	if(DeviceType == DeviceType_dbj_zw_bmh
		&& mpd.carriersVersions == BMH)
		return false;
	else
		return false;
}

bool checkDeviceType_isExist(u8 tmp_DeviceType)
{
	switch(tmp_DeviceType)
	{
		case DeviceType_none:
		case DeviceType_dbj_zw_bmh:
			return true;
		default:
			return false;
	}
}

void set_hardwareState_defaultValue(void)
{
//  hardwareState.lamp = true;
//	hardwareState.fan = true;
//	hardwareState.camera = Enable_Camera_Default;
//	hardwareState.check_door = Enable_Check_Door;
//	hardwareState.check_qle = Enable_Check_G_QLE_IsExist;
//	hardwareState.check_xz6 = Enable_Check_XZ6_Default;
}

/* ***************************************��ʱ����*********************************** */
//_calendar_obj tmpDateTime;


/* *************************************** ȫ�ֺ��� *********************************** */
// ��ȡ�豸���к�
void getDeviceSnNumber(void)
{
    u32 ChipUniqueID[3];
	//��ַ��С����,�ȷŵ��ֽڣ��ٷŸ��ֽڣ�С��ģʽ
	//��ַ��С����,�ȷŸ��ֽڣ��ٷŵ��ֽڣ����ģʽ
	ChipUniqueID[2] = *(__IO u32*)(0X1FFFF7E8);  // ���ֽ�
	ChipUniqueID[1] = *(__IO u32 *)(0X1FFFF7EC); // 
	ChipUniqueID[0] = *(__IO u32 *)(0X1FFFF7F0); // ���ֽ� 
	deviceSnNumber = (long)((ChipUniqueID[0] ^ ChipUniqueID[1] ^ ChipUniqueID[2])&0xffffff);
}


// ����ʱ���ȡ����
u8 set_alarmSeccount(u32* alarmSeccount, u16 syear,u8 smon,u8 sday,u8 hour,u8 min,u8 sec)
{
    u16 t;
    u32 seccount=0;
    if(syear<1970||syear>2099)return 1;
    for(t=1970; t<syear; t++)	//��������ݵ��������
    {
        if(Is_Leap_Year(t))seccount+=31622400;//�����������
        else seccount+=31536000;			  //ƽ���������
    }
    smon-=1;
    for(t=0; t<smon; t++)	 //��ǰ���·ݵ����������
    {
        seccount+=(u32)mon_table[t]*86400;//�·����������
        if(Is_Leap_Year(syear)&&t==1)seccount+=86400;//����2�·�����һ���������
    }
    seccount+=(u32)(sday-1)*86400;//��ǰ�����ڵ����������
    seccount+=(u32)hour*3600;//Сʱ������
    seccount+=(u32)min*60;	 //����������
    seccount+=sec;//�������Ӽ���ȥ
    *alarmSeccount = seccount;
    return 0;
}



bool checkBCC(u8 *data, u8 dataLength)
{
    u8 i = 0, tmpU8 = 0;
    for(i = 0; i < dataLength - 2; i++)
        tmpU8 = tmpU8 ^ data[i];
    if(tmpU8 == data[dataLength - 2])
        return true;
    else
        return false;
}

void setBCC(u8 *data, u8 dataLength)
{
    u8 i = 0, bcc = 0;
    for(i = 0; i < dataLength - 2; i++)
        bcc = bcc ^ data[i];
    data[dataLength - 2] = bcc;
}

void checkPirate(void)
{
	// �������ʧ�ܣ������ǵ��棬�ƻ�����
	if(verifyCiphertextExistError())					
	{
		// ����������Ѿ��������رն���������ʽ��оƬ
		if(FLASH_GetReadOutProtectionStatus() == SET)
			close_FlashReadProtect();	
		// ������δ�������ȴ򿪣����¿����ٸ�ʽ��
		else
		{
			open_FlashReadProtect();
			POWER = !POWER_ON;
		}
	}
}



// ����ר��
void printfCpuState(void)
{
    debugUart_send_autoLength("CPU:");
    debugUart_sendInt(OSCPUUsage);
    debugUart_send_autoLength("%  MEM:");
    debugUart_sendInt(my_mem_perused(SRAMIN));
    debugUart_send_autoLength("%\r\n");
}

// ����ר��
void printfPositionState(void)
{
//    debugUart_send_autoLength("position XZ:");
//    debugUart_sendInt(motorInfo_XZ.position);
    debugUart_send_autoLength(" X:");
    debugUart_sendInt(motorInfo_X.position);
    debugUart_send_autoLength(" Y:");
    debugUart_sendInt(motorInfo_Y.position);
//    debugUart_send_autoLength(" C:");
//    debugUart_sendInt(motorInfo_C.position);
//    debugUart_send_autoLength(" D:");
//    debugUart_sendInt(motorInfo_D.position);
//    debugUart_send_autoLength("\r\n");
}

// ����ר��
void printfDeviceState(void)
{
//	debugUart_send_autoLength("\r\n");
//	debugUart_send_autoLength(" programIndex:");
//  debugUart_sendInt(deviceState.programIndex);
//	debugUart_send_autoLength("\r\n");
//	debugUart_send_autoLength(" stepTotalCount:");
//	debugUart_sendInt(deviceState.stepTotalCount);
//	debugUart_send_autoLength(" nowRunStepIndex:");
//	debugUart_sendInt(deviceState.nowRunStepIndex);
//	debugUart_send_autoLength("\r\n");
//	debugUart_send_autoLength("startStepIndex:");
//	debugUart_sendInt(deviceState.startStepIndex);
//	debugUart_send_autoLength(" endStepIndex:");
//	debugUart_sendInt(deviceState.endStepIndex);
//	debugUart_send_autoLength("\r\n");
//	debugUart_send_autoLength(" askPause:");
//	debugUart_sendInt(deviceState.askPause);
//	
//	debugUart_send_autoLength("\r\nmainThread:\r\n");
//	debugUart_send_autoLength(" runState:");
//	debugUart_sendInt(deviceState.main_runningState);
//	debugUart_send_autoLength(" Group:");
//	debugUart_sendInt(deviceState.main_motionGroup);
//	debugUart_send_autoLength(" motion:");
//	debugUart_sendInt(deviceState.main_motion);
//	debugUart_send_autoLength(" state:");
//	debugUart_sendInt(deviceState.main_motionState);

//	debugUart_send_autoLength("\r\nmotorXThread:\r\n");
//	debugUart_send_autoLength(" runState:");
//	debugUart_sendInt(deviceState.motorX_runningState);
//	debugUart_send_autoLength(" Group:");
//	debugUart_sendInt(deviceState.motorX_motionGroup);
//	debugUart_send_autoLength(" motion:");
//	debugUart_sendInt(deviceState.motorX_motion);
//	debugUart_send_autoLength(" State:");
//	debugUart_sendInt(deviceState.motorX_motionState);
//	debugUart_send_autoLength("\r\n");
	
}


void printfGdState(void)
{
//	debugUart_send_autoLength("XZ6:");
//	debugUart_sendInt(XZ6);
	debugUart_send_autoLength(" XH:");
	debugUart_sendInt(XH);
	debugUart_send_autoLength(" XE:");
	debugUart_sendInt(XE);
//	debugUart_send_autoLength(" XZH:");
//	debugUart_sendInt(XZH);
	debugUart_send_autoLength("\r\nYH:");
	debugUart_sendInt(YH);
	debugUart_send_autoLength(" YE:");
	debugUart_sendInt(YE);
//	debugUart_send_autoLength(" G_SL:");
//	debugUart_sendInt(G_SL);
	debugUart_send_autoLength(" XEG:");
	debugUart_sendInt(XEG);
//	debugUart_send_autoLength(" G_QLE:");
//	debugUart_sendInt(G_QLE);
}


void printfStepData(void)
{

}

void printfTempData(void)
{

}

void printfMpd(void)
{
//	debugUart_send_autoLength("check_XZ6:");
//	debugUart_sendInt(mpd.check_XZ6_enable);
//	debugUart_send_autoLength(" XZ_1d:");
//	debugUart_sendInt(mpd.XZ_1d);
	debugUart_send_autoLength(" X_1mm:");
	debugUart_sendInt(mpd.X_1mm);
	debugUart_send_autoLength(" Y_1mm:");
	debugUart_sendInt(mpd.Y_1mm);
//	debugUart_send_autoLength("\r\nXZ_defaultFreq:");
//	debugUart_sendInt(mpd.XZ_accStartFreq);
	debugUart_send_autoLength(" X_accStartFreq:");
	debugUart_sendInt(mpd.X_accStartFreq);
	debugUart_send_autoLength(" Y_accStartFreq:");
	debugUart_sendInt(mpd.Y_accStartFreq);
//	debugUart_send_autoLength("\r\nXZ_site_1:");
//	debugUart_sendInt(mpd.XZ_site_1);
//	debugUart_send_autoLength(" XZ_site_2:");
//	debugUart_sendInt(mpd.XZ_site_2);
//	debugUart_send_autoLength(" XZ_site_3:");
//	debugUart_sendInt(mpd.XZ_site_3);
//	debugUart_send_autoLength(" XZ_site_4:");
//	debugUart_sendInt(mpd.XZ_site_4);
//	debugUart_send_autoLength(" XZ_site_5:");
//	debugUart_sendInt(mpd.XZ_site_5);
//	debugUart_send_autoLength(" XZ_site_6:");
//	debugUart_sendInt(mpd.XZ_site_6);
	debugUart_send_autoLength("\r\nX_end:");
	debugUart_sendInt(mpd.X_end);
//	debugUart_send_autoLength(" QL_home:");
//	debugUart_sendInt(mpd.QL_home);
	debugUart_send_autoLength(" Y_end:");
	debugUart_sendInt(mpd.Y_end);
}

void printfMotionState(void)
{
	if(deviceState.motorReset_runningState != RunningState_none)
	{
		debugUart_send_autoLength("\r\nmotorReset ");
		printfRunningState(deviceState.motorReset_runningState);
		printfMotionName(deviceState.motorReset_motion);
		printfMotorState(deviceState.motorReset_motionState);
		debugUart_send_autoLength("\r\n");
	}
	if(deviceState.pushinBox_runningState != RunningState_none)
	{
		debugUart_send_autoLength("\r\npushinBox ");
		printfRunningState(deviceState.pushinBox_runningState);
		printfMotionName(deviceState.pushinBox_motion);
		printfMotorState(deviceState.pushinBox_motionState);
		debugUart_send_autoLength("\r\n");
	}
	if(deviceState.pushOutBox_runningState != RunningState_none)
	{
		debugUart_send_autoLength("\r\npushOutBox ");
		printfRunningState(deviceState.pushOutBox_runningState);
		printfMotionName(deviceState.pushOutBox_motion);
		printfMotorState(deviceState.pushOutBox_motionState);
		debugUart_send_autoLength("\r\n");
	}
}

void printfMotorState(u8 motionState)
{
	debugUart_send_autoLength(" motionState:");
	switch(motionState)
	{
		case 0:
			debugUart_send_autoLength(" waitExecute");
			break;
		case 1:
			debugUart_send_autoLength(" executing");
			break;
		case 2:
			debugUart_send_autoLength(" executeFinish");
			break;
	}
}

void printfRunningState(u8 runningState)
{
	debugUart_send_autoLength(" runningState:");
	switch(runningState)
	{
		case 0:
			debugUart_send_autoLength(" none");
			break;
		case 1:
			debugUart_send_autoLength(" readyStart");
			break;
		case 2:
			debugUart_send_autoLength(" running");
			break;
		case 3:
			debugUart_send_autoLength(" pause");
			break;
		case 4:
			debugUart_send_autoLength(" readyFinish");
			break;
		case 5:
			debugUart_send_autoLength(" finish");
			break;
		case 6:
			debugUart_send_autoLength(" error");
			break;
	}
}

void printfMotionName(u8 motion)
{
	debugUart_send_autoLength("\r\nmotion:");
	switch(motion)
	{
		case 0:
			debugUart_send_autoLength(" Motion_none");
			break;
		case 1:
			debugUart_send_autoLength(" Motion_X_zero");
			break;
		case 2:
			debugUart_send_autoLength(" Motion_X_end");
			break;
		case 3:
			debugUart_send_autoLength(" Motion_X_readyZero");
			break;
		case 4:
			debugUart_send_autoLength(" Motion_Y_zero");
			break;
		case 5:
			debugUart_send_autoLength(" Motion_Y_end");
			break;
		case 6:
			debugUart_send_autoLength(" Motion_Y_readyZero");
			break;
		case 7:
			debugUart_send_autoLength(" Motion_X_CheckState");
			break;
		case 8:
			debugUart_send_autoLength(" Motion_Y_CheckState");
			break;
		case 9:
			debugUart_send_autoLength(" Motion_Check_XEG");
			break;
		case 10:
			debugUart_send_autoLength(" Motion_Check_XH");
			break;
		case 11:
			debugUart_send_autoLength(" Motion_Check_YH");
			break;
		case 12:
			debugUart_send_autoLength(" Motion_Wait_boxDown");
			break;
	}
}

