#include "motionControl.h"
#include "math.h"
#include "GlobalInclude.h"
// ��������
void programThread_main(void);
void timerThread_motorReset(void);
void waitExecute_motorReset(void);
void executing_motorReset(void);
void executeFinish_motorReset(void);
volatile bool motorReset_GSLH_AlreadyCheck = false;	// �Ѿ��������
volatile u16 executing_delayCheck_1ms = 0;
void timerThread_pushinBox(void);
void waitExecute_pushinBox(void);
void executing_pushinBox(void);
void executeFinish_pushinBox(void);
volatile u8 pushinBox_planSite = 0;	// �ƻ��ƶ�����λ��
void timerThread_pushOutBox(void);

// ��������
volatile u32 delay_1ms = 0;
volatile bool timeout_enable = true;
volatile u32 timeout_delay_1ms = 0;
volatile u16 timeout_second = 0;
volatile u8 waitExecute_runCount_pushinBox = 0;
volatile bool pushinBox_alreadyPushin = 0;
u8 tmpU8 = 0;
u16 tmpU16 = 0;
u16 tmp2U16 = 0;
int planPosition = 0;



// ����ִ�г��򣬶�ʱ��6�Ϸ������1ms�ж�һ��
void TIM6_IRQHandler(void)   //TIM6�ж�
{
	tmpU8 = 0;
	tmpU16 = 0;
	tmp2U16 = 0;
	planPosition = 0;	
	if (TIM_GetITStatus(TIM6, TIM_IT_Update) != RESET)  //���TIM6�����жϷ������
	{
		delay_1ms++;
		timeout_delay_1ms++;
		TIM_ClearITPendingBit(TIM6, TIM_IT_Update);  //���TIMx�����жϱ�־
//		programThread_main();
		// �����Ҫˮƽ���/����
		timerThread_motorReset();
		timerThread_pushinBox();
		timerThread_pushOutBox();
	}
}

// ��λ �����߳�
void timerThread_motorReset(void)
{
	if(deviceState.motorReset_threadEnable != ON)
		return;

	switch(deviceState.motorReset_runningState)
	{
		// ����û����ִ��
		case RunningState_none:
			break;
		// ׼��������һ������
		case RunningState_readyStart:
		{
			deviceState.pushinBox_runningState = RunningState_none;
			deviceState.pushinBox_threadEnable = OFF;
			deviceState.pushOutBox_runningState = RunningState_none;
			deviceState.pushOutBox_threadEnable = OFF;
			
			deviceState.taskType = TaskType_motorReset;
			deviceState.motorReset_runningState = RunningState_running;
			deviceState.motorReset_motionState = MotionState_waitExecute;
			deviceState.motorReset_motion = Motion_Y_CheckState;
			motorReset_GSLH_AlreadyCheck = false;
			delay_1ms = 0;
			timeout_delay_1ms = 0;
			break;
		}
		// ��ǰ״̬��������
		case RunningState_running:
		{	
			// �ж϶���ִ��״̬
			switch(deviceState.motorReset_motionState)
			{
				// ��ǰ�ж����ȴ�ִ��
				case MotionState_waitExecute:
					{
						if(debugState.motionState)
							printfMotionState();
						waitExecute_motorReset();
					}
					break; 
				case MotionState_executing:
					// ִ�г�ʱ���
					if(timeout_enable == true 
						&& timeout_delay_1ms > 1000 * timeout_second)
					{
						deviceState.motorReset_runningState = RunningState_error;
						// �ϴ���Ϣ����λ��ʱ
						if(deviceState.waitAck)
							ack_3data(deviceState.waitAckIndex, Type_controlAck, Fc_run,
								Extra_run_motorReset, AckResult_executeFailed, 
								Reason_timeOut, deviceState.motorReset_motion);
						break;
					}
					executing_motorReset();
					break; 
				case MotionState_executeFinish:
					if(debugState.motionState)
							printfMotionState();
					executeFinish_motorReset();
					break;
			} 
			break;
		}
		// ��ͣ��
		case RunningState_pause:
			break;
		// ��ǰ״̬׼��ֹͣ
		case RunningState_readyFinish:
		{
			deviceState.motorReset_motion = Motion_none;
			deviceState.motorReset_motionState = MotionState_waitExecute;
			deviceState.motorReset_runningState = RunningState_finish;
			deviceState.motorReset_threadEnable = OFF;
			deviceState.nowSite = 1;
			// �ϴ���Ϣ����λ���
			if(deviceState.waitAck)
				ack(deviceState.waitAckIndex, Type_controlAck, Fc_run,
									Extra_run_motorReset, AckResult_executeSucceed);
			break;
		}
		case RunningState_error:
			break;
	}	
}
// ��λ�����߳� ׼��ִ��
void waitExecute_motorReset(void)
{
	timeout_second = 10;
	deviceState.motorReset_motionState = MotionState_executing;
	executing_delayCheck_1ms = 0;
	switch (deviceState.motorReset_motion)
	{
		// ������ϼ� (���ϼܵ�ǰλ�ã��м䡢ԭ�㡢�յ�)
		case Motion_Y_CheckState:
		{
			// ���ϼ� ���м䣬ȥ�յ�(�ϵ�������Ƴ���Ƭ;�л򷵻�ԭ��;��)
			if(YH != YH_Blocking
				&& YE != YE_Blocking)
			{
				motorInfo_Y.position = 0;
				deviceState.motorReset_motion = Motion_Y_end;
			}
			// ���ϼ� ��ԭ��
			else if(YH == YH_Blocking)
			{
				motorInfo_Y.position = 0;
				deviceState.motorReset_motion = Motion_Y_readyZero;
			}
			// ���ϼ� ���յ� ,ȥԭ��(�ϵ�������Ƴ���Ƭ�յ��յ�)
			else if(YE == YE_Blocking) 
			{
				motorInfo_Y.position = mpd.Y_end;
				deviceState.motorReset_motion = Motion_Y_zero;
			}
			deviceState.motorReset_motionState = MotionState_waitExecute;
			break;
		}
		// ���ϼ� ȥ�յ�
		case Motion_Y_end:
		{
			motorGo_acc(Motor_Y, mpd.Y_end);
			break;
		}
		case Motion_Y_readyZero:
		{
			planPosition = mpd.Y_1mm * ReadyZero_moveDistance;
			motorGo_acc(Motor_Y, planPosition);
			break;
		}
		// ���ϼ� ȥԭ��
		case Motion_Y_zero:
		{
			motorGo_acc(Motor_Y, 0);
			break;
		}
		// ������ϼ� (���ϼܵ�ǰλ�ã��м䡢ԭ�㡢�յ�)
		case Motion_X_CheckState:
		{
			// ���ϼ� ���м�
			if(XH != XH_Blocking
				&& XE != XE_Blocking)
			{
				// ��ӡ���޲�Ƭ��ȥ�յ�(�ϵ�������ƽ���Ƭ����ӡ��;��)
				if(XEG != XEG_ExistBox)
				{
					motorInfo_X.position = 0;
					deviceState.motorReset_motion = Motion_X_end;
					deviceState.motorReset_motionState = MotionState_waitExecute;
				}
				// ��ӡ���в�Ƭ����ԭ��(�ϵ�������ƽ���Ƭ�귵��ԭ��;��)
				else
				{
					motorInfo_X.position = mpd.X_end;
					deviceState.motorReset_motion = Motion_X_zero;
					deviceState.motorReset_motionState = MotionState_waitExecute;
				}
			}
			// ���ϼ� ��ԭ�� ,ȥ׼ԭ��
			else if(XH == XH_Blocking) 
			{
				motorInfo_X.position = 0;
				deviceState.motorReset_motion = Motion_X_readyZero;
			}
			// ���ϼ� ���յ� ,ȥԭ��(�ϵ�������ƽ���Ƭ�յ���ӡ��)
			else if(XE == XE_Blocking) 
			{
				motorInfo_X.position = mpd.X_end;
				deviceState.motorReset_motion = Motion_X_zero;
			}
			deviceState.motorReset_motionState = MotionState_waitExecute;
			break;
		}
		case Motion_X_end:
		{
			motorGo_acc(Motor_X, mpd.X_end);
			break;
		}
		case Motion_X_readyZero:
		{
			planPosition = mpd.X_1mm * ReadyZero_moveDistance;
			motorGo_acc(Motor_X, planPosition);
			break;
		}
		case Motion_X_zero:
		{
			motorGo_acc(Motor_X, 0);
			break;
		}
		// ����� ��ӡ������ (״̬���С���)
		case Motion_Check_XEG:
		{
			motorReset_GSLH_AlreadyCheck = true;
//			// ��ӡ������ ���ڣ��ƶ����ϼ�
//			if(XEG == XEG_ExistBox && (XH == XH_Blocking || XE == XE_Blocking))
//				deviceState.motorReset_motion = Motion_Y_end;
//			// ��ӡ������ �����ڣ����ƶ����ϼ�
//			else if(XEG != XEG_ExistBox)
//				{deviceState.motorReset_runningState = RunningState_readyFinish;}
//			deviceState.motorReset_motionState = MotionState_waitExecute;
			
			// ��ӡ������ ���ڣ��ƶ����ϼ�
			if(XEG == XEG_ExistBox)
			{
				deviceState.motorReset_motion = Motion_Y_end;
				deviceState.motorReset_motionState = MotionState_waitExecute;
			}
			// ��ӡ������ �����ڣ�����
			else 
				deviceState.motorReset_motionState = MotionState_executeFinish;
			break;
		}
	}
}
// ��λ�����߳� ִ����
void executing_motorReset(void)
{
	executing_delayCheck_1ms ++;
	if(executing_delayCheck_1ms < 20)
		return ;
	switch (deviceState.motorReset_motion)
	{
		case Motion_Y_CheckState:
			break;
		case Motion_Y_end:
			checkMotionExecuteState_threadName(Motor_Y, ThreadName_motorReset);
			break;
		case Motion_Y_readyZero:
			checkMotionExecuteState_threadName(Motor_Y, ThreadName_motorReset);
			break;
		case Motion_Y_zero:
			checkMotionExecuteState_threadName(Motor_Y, ThreadName_motorReset);
			break;
		case Motion_X_CheckState:
			break;
		case Motion_X_end:
			checkMotionExecuteState_threadName(Motor_X, ThreadName_motorReset);
			break;
		case Motion_X_readyZero:
			checkMotionExecuteState_threadName(Motor_X, ThreadName_motorReset);
			break;
		case Motion_X_zero:
			checkMotionExecuteState_threadName(Motor_X, ThreadName_motorReset);
			break;
		case Motion_Check_XEG:
			break;
	}
}
// ��λ�����߳� ִ�����
void executeFinish_motorReset(void)
{
	timeout_delay_1ms = 0;
	deviceState.motorReset_motionState = MotionState_waitExecute;
	switch (deviceState.motorReset_motion)
	{
		case Motion_Y_CheckState:
			break;
		case Motion_Y_end:
			deviceState.motorReset_motion = Motion_Y_zero;
			break;
		case Motion_Y_readyZero:
			deviceState.motorReset_motion = Motion_Y_zero;
			break;
		case Motion_Y_zero:
			// ����м��ǰ
			if(motorReset_GSLH_AlreadyCheck != true)
			{
				deviceState.motorReset_motion = Motion_X_CheckState;
			}
			// ����м���
			else
				deviceState.motorReset_runningState = RunningState_readyFinish;
			break;
		case Motion_X_CheckState:
			break;
		case Motion_X_end:
			deviceState.motorReset_motion = Motion_X_zero;
			break;
		case Motion_X_readyZero:
			deviceState.motorReset_motion = Motion_X_zero;
			break;
		case Motion_X_zero:
			deviceState.motorReset_motion = Motion_Check_XEG;
			break;
		case Motion_Check_XEG:
			deviceState.motorReset_runningState = RunningState_readyFinish;
			break;
	}
}







// ���� �����߳�
void timerThread_pushinBox(void)
{
	if(deviceState.pushinBox_threadEnable != ON)
		return;

	switch(deviceState.pushinBox_runningState)
	{
		case RunningState_none:
			break;
		// ׼��������һ������
		case RunningState_readyStart:
		{
			// ��������߳�״̬
			deviceState.motorReset_runningState = RunningState_none;
			deviceState.motorReset_threadEnable = OFF;	
			deviceState.pushOutBox_runningState = RunningState_none;
			deviceState.pushOutBox_threadEnable = OFF;	

			deviceState.taskType = TaskType_pushinBox;
			deviceState.pushinBox_runningState = RunningState_running;
			deviceState.pushinBox_motionState = MotionState_waitExecute;
			deviceState.pushinBox_motion = Motion_Check_XEG;
			waitExecute_runCount_pushinBox = 0;
			pushinBox_alreadyPushin = false;
			delay_1ms = 0;
			timeout_delay_1ms = 0;
			break;
		}
		// ��ǰ״̬��������
		case RunningState_running:
		{	
			// �ж϶���ִ��״̬
			switch(deviceState.pushinBox_motionState)
			{
				// ��ǰ�ж����ȴ�ִ��
				case MotionState_waitExecute:
					if(debugState.motionState)
							printfMotionState();
					waitExecute_pushinBox();
					break; 
				case MotionState_executing:
					// ִ�г�ʱ���
					if(timeout_enable == true 
						&& timeout_delay_1ms > 1000 * timeout_second)
					{
						deviceState.pushinBox_runningState = RunningState_error;
						// �ϴ���Ϣ���̳߳�ʱ
						if(deviceState.waitAck)
							ack_3data(deviceState.waitAckIndex, Type_controlAck, Fc_run,
								Extra_run_pushinBox, AckResult_executeFailed,
								Reason_timeOut, deviceState.pushinBox_motion);
						break;
					}
					executing_pushinBox();
					break; 
				case MotionState_executeFinish:
					if(debugState.motionState)
							printfMotionState();
					executeFinish_pushinBox();
					break;
			} 
			break;
		}
		case RunningState_pause:
			break;
		// ��ǰ״̬׼��ֹͣ
		case RunningState_readyFinish:
			deviceState.pushinBox_motion = Motion_none;
			deviceState.pushinBox_motionState = MotionState_waitExecute;
			deviceState.pushinBox_runningState = RunningState_finish;
			deviceState.pushinBox_threadEnable = OFF;
		 // �ϴ���Ϣ���������
			if(deviceState.waitAck)
				ack_2data(deviceState.waitAckIndex, Type_controlAck, Fc_run,
									Extra_run_pushinBox, AckResult_executeSucceed, deviceState.nowSite);
			break;
		case RunningState_error:
			break;
	}	
}

// �����߳� ׼��ִ��
void waitExecute_pushinBox(void)
{
	deviceState.pushinBox_motionState = MotionState_executing;
	timeout_second = 10;
	executing_delayCheck_1ms = 0;
	switch (deviceState.pushinBox_motion)
	{
		// ���ϼ� �ƶ������ ��ӡ���޲�Ƭ�������
		case Motion_X_end:
		{
			//if(XEG != XEG_ExistBox && XH == XH_Blocking)
			if(XE != XE_Blocking)
				motorGo_acc(Motor_X, mpd.X_end);
			else
				deviceState.pushinBox_motionState = MotionState_executeFinish;
			break;
		}
		// ���ϼ� ��ԭ�� �������
		case Motion_X_zero:
		{
			if(XH != XH_Blocking)
				motorGo_acc(Motor_X, 0);
			else
				deviceState.pushinBox_motionState = MotionState_executeFinish;
			break;
		}
		// ��� ��ӡ�� ���޲�Ƭ
		case Motion_Check_XEG:
		{
			// ��ӡ�� �в�Ƭ
			if(XEG == XEG_ExistBox)
			{
//				// ��û�Ʋ�Ƭ��X�᲻��ԭ�㣬��ԭ��
//				if(pushinBox_alreadyPushin == false
//					&& XH != XH_Blocking)
//				{
//					deviceState.pushinBox_motionState = MotionState_waitExecute;
//					deviceState.pushinBox_motion = Motion_X_zero;
//					waitExecute_runCount_pushinBox = 0;
//					pushinBox_alreadyPushin = true;
//					return;
//				}
				// ��ӡ���в�Ƭ�� �Ѿ����˲�Ƭ �� δ�Ʋ�Ƭ��X����ԭ��
				deviceState.pushinBox_motionState = MotionState_executeFinish;
			}
			// ��ӡ�� �޲�Ƭ
			else
			{
				// �״�ִ�У��Ʋ�Ƭ
				if(pushinBox_alreadyPushin == false)
				{
					deviceState.pushinBox_motionState = MotionState_waitExecute;
					deviceState.pushinBox_motion = Motion_X_end;
					waitExecute_runCount_pushinBox = 0;
					return;
				}
				// �ƹ���Ƭ�ˣ���Ȼ�޲�Ƭ����ʾȱ�ٲ�Ƭ
				else
				{
					// �ϴ���Ϣ��ȱ�ٰ���� (�ƶ�ʧ�ܣ�
					deviceState.pushinBox_runningState = RunningState_error;
					if(deviceState.waitAck)
						ack_3data(deviceState.waitAckIndex, Type_controlAck, Fc_run,
							Extra_run_pushinBox, AckResult_executeFailed,
							Reason_XEG_withoutBox, deviceState.nowSite);
				}
			}
		}
	}
	waitExecute_runCount_pushinBox ++;
}
// �����߳� ִ����
void executing_pushinBox(void)
{
	executing_delayCheck_1ms ++;
	if(executing_delayCheck_1ms < 20)
		return ;
	waitExecute_runCount_pushinBox = 0;
	switch (deviceState.pushinBox_motion)
	{
		case Motion_X_end:
		{
			checkMotionExecuteState_threadName(Motor_X, ThreadName_pushinBox);
			break;
		}
		case Motion_X_zero:
		{
			checkMotionExecuteState_threadName(Motor_X, ThreadName_pushinBox);
			break;
		}
		case Motion_Check_XEG:
		{
			break;
		}

	}
}
// �����߳� ִ�����
void executeFinish_pushinBox(void)
{
	timeout_delay_1ms = 0;
	deviceState.pushinBox_motionState = MotionState_waitExecute;
	switch (deviceState.pushinBox_motion)
	{
		case Motion_X_end:
		{
			pushinBox_alreadyPushin = true;
			deviceState.pushinBox_motion = Motion_X_zero;
			break;
		}
		case Motion_X_zero:
		{
			deviceState.pushinBox_motion = Motion_Check_XEG;
			break;
		}
		case Motion_Check_XEG:
		{
			deviceState.pushinBox_runningState = RunningState_readyFinish;
			break;
		}
	}
}

// ���ϼ� �ư�����߳�
void timerThread_pushOutBox(void)
{
	if(deviceState.pushOutBox_threadEnable != ON)
		return;

	switch(deviceState.pushOutBox_runningState)
	{
		// ׼��������һ������
		case RunningState_readyStart:
		{
			// ��������߳�״̬
			deviceState.motorReset_runningState = RunningState_none;
			deviceState.motorReset_threadEnable = OFF;	
			deviceState.pushinBox_runningState = RunningState_none;
			deviceState.pushinBox_threadEnable = OFF;

			deviceState.taskType = TaskType_pushOutBox;
			deviceState.pushOutBox_runningState = RunningState_running;
			deviceState.pushOutBox_motionState = MotionState_waitExecute;
			deviceState.pushOutBox_motion = Motion_Y_end;
			delay_1ms = 0;
			timeout_delay_1ms = 0;
			break;
		}
		// ��ǰ״̬��������
		case RunningState_running:
		{	
			// �ж϶���ִ��״̬
			switch(deviceState.pushOutBox_motionState)
			{
				// ��ǰ�ж����ȴ�ִ��
				case MotionState_waitExecute:
				{
					if(debugState.motionState)
							printfMotionState();
					deviceState.pushOutBox_motionState = MotionState_executing;
					timeout_second = 10;
					executing_delayCheck_1ms = 0;
					switch (deviceState.pushOutBox_motion)
					{
						// ���ϼ� ���յ㣬���������ϼ����յ�����
						case Motion_Y_end: 
						{
							if(YE != YE_Blocking)
								motorGo_acc(Motor_Y, mpd.Y_end);
							else
								deviceState.pushOutBox_motionState = MotionState_executeFinish;
							break; 
						}
						// ���ϼ� ��ԭ�㣬��ֹ����
						case Motion_Y_zero:
						{
							if(YH != YH_Blocking)
								motorGo_acc(Motor_Y, 0);
							else
								deviceState.pushOutBox_motionState = MotionState_executeFinish;
							break; 
						}
					}
					break; 
				}
				case MotionState_executing:
				{
					// ִ�г�ʱ���
					if(timeout_enable == true 
						&& timeout_delay_1ms > 1000 * timeout_second)
					{
						deviceState.pushOutBox_runningState = RunningState_error;
						// �ϴ���Ϣ���Ƴ������ ��ʱ
						if(deviceState.waitAck)
							ack_3data(deviceState.waitAckIndex, Type_controlAck, Fc_run,
								Extra_run_pushOutBox, AckResult_executeFailed,
								Reason_timeOut, deviceState.pushOutBox_motion);
						break;
					}
					executing_delayCheck_1ms ++;
					if(executing_delayCheck_1ms < 20)
						return ;
					switch (deviceState.pushOutBox_motion)
					{
						case Motion_Y_end:
						{
							checkMotionExecuteState_threadName(Motor_Y, ThreadName_pushOutBox);
							break; 
						}
						case Motion_Y_zero:
						{
							checkMotionExecuteState_threadName(Motor_Y, ThreadName_pushOutBox);
							break; 
						}
					}
					break; 
				}
				case MotionState_executeFinish:
				{
					timeout_delay_1ms = 0;
					if(debugState.motionState)
							printfMotionState();
					deviceState.pushOutBox_motionState = MotionState_waitExecute;
					switch (deviceState.pushOutBox_motion)
					{
						case Motion_Y_end:
						{
							deviceState.pushOutBox_motion = Motion_Y_zero;
							break; 
						}
						case Motion_Y_zero:
						{
							deviceState.pushOutBox_runningState = RunningState_readyFinish;
							break; 
						}
					}
					break;
				}
			} 
			break;
		}
		// ��ǰ״̬׼��ֹͣ
		case RunningState_readyFinish:
			deviceState.pushOutBox_motion = Motion_none;
			deviceState.pushOutBox_motionState = MotionState_waitExecute;
			deviceState.pushOutBox_runningState = RunningState_finish;
			deviceState.pushOutBox_threadEnable = OFF;
		 // �ϴ���Ϣ���ɹ��Ƴ������
			if(deviceState.waitAck)
				ack(deviceState.waitAckIndex, Type_controlAck, Fc_run,
									Extra_run_pushOutBox, AckResult_executeSucceed);
			break;
		case RunningState_error:
			break;
	}	
}






// ����߳��Ƿ����
bool check_deviceCanControl(void)
{
	u8 state = 0;
	switch(deviceState.taskType)
	{
		case TaskType_motorReset:
			state = deviceState.motorReset_runningState;
			break;
		case TaskType_pushinBox:
			state = deviceState.pushinBox_runningState;
			break;
		case TaskType_pushOutBox:
			state = deviceState.pushOutBox_runningState;
			break;
		default:
			return false;
	}
	if(state == RunningState_none
		|| state == RunningState_finish)
		return true;
	else
		return false;
}
