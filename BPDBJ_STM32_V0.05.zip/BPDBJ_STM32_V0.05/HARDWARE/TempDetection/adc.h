#ifndef __ADC_H
#define __ADC_H	
#include "sys.h"

void Adc_Init(void);
u16  Get_Adc(u8 ch); 
u16 Get_Adc_Average(u8 ch,u8 times,u16 delayUs); 

void TempDetection_Gpio_Init(void);
void TempDetection_SetChannels(u8 channels);
void TempDetection_SetChannelsEnable(u8 enable);// ����ʹ������

float ResCalculate(u8 ch,u8 times,u16 delayUs);
float TempCalculate(float Value_Res);
float GetTemp(u8 channels, u8 times, u16 delayUs);
void getTemp(void);
//u16 checkTempSensor_existBad(void);
// ����¶��������޴���
u16 checkTempArray_existBad(void);

#endif 
