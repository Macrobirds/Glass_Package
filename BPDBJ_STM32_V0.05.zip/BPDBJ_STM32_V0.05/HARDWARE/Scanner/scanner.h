#ifndef __SCANNER_H
#define __SCANNER_H	    
#include <stm32f10x.h>
void initScanner(void);
void openScanner(void);
void closeScanner(void);
void checkScannerData(void);
void cleanScannerData(void);
#endif


