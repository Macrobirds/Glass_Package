#ifndef __GPIO_H
#define __GPIO_H
#include <stm32f10x.h>
void Motor_GPIO_Init(void);
void LED_GPIO_Init(void);
void Buzzer_GPIO_Init(void);
void RELAY_GPIO_Init(void);
void POWER_GPIO_Init(void);
void Heater_Gpio_Init(void);
void Not_Use_Gpio_Init(void);

#endif
