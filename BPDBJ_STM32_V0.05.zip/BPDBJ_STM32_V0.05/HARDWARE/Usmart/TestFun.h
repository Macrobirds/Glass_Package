#ifndef __TESTFUN_H
#define __TESTFUN_H
#include <stm32f10x.h>
#include "sys.h"

void Test_FunID(void(*fun)(void));
void flashReadProtect(u8 controlType);
void showMachineInfo(void);
void writeProgramVersions(u32 serialNumber);
void writeMachineId(u32 machineId);
void setDebugState(u8 debugStateNumber, u8 onOff);
void beep(u8 onOff);
void motorReset(void);
void pushinBox(void);
void pushOutBox(void);
#endif


