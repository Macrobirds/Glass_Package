#ifndef __HERTER_H
#define __HERTER_H	
#include "sys.h"

// ���Ƽ��Ȱ�
void openHeater(u8 index);
void closeHeater(u8 index);
void closeAllHeater(void);
u8 checkHeater(u8 heatHole, u16 tempArray_U16[]);
void changeHeater_3Channel(u8 channel);
void openHeater_3Channel(u8 channel);
void closeHeater_3Channel(u8 channel);

typedef struct PID {

     float SetPoint;   // �趨Ŀ�� Desired value
     float Proportion; // �������� Proportional Const
     float Integral;   // ���ֳ��� Integral Const
     float Derivative; // ΢�ֳ��� Derivative Const
     float LastError;  // Error[-1]
     float PrevError;  // Error[-2]
     float SumError;   // Sums of Errors
} PID;

extern PID temp_PID;
extern  void pid_init (PID *pp);
extern  int  pid_calc( PID *pp, int NowPoint );

#endif 
