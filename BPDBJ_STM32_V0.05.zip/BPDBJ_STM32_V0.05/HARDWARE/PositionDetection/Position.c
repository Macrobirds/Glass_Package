#include "GlobalInclude.h"
void Exti_Init_0_6(void);
void Exti_Init_8_15(void);

void Exti_Init(void)
{
  Exti_Init_8_15();
}

// λ�ü��
void Exti_8_15_GPIO_Init(void) 
{ 
	// PE8-15
 	GPIO_InitTypeDef GPIO_InitStructure;
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE,ENABLE);
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|
		 GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;//���ó��������� 
 	GPIO_Init(GPIOE, &GPIO_InitStructure);
}

//�ⲿ�ж� �������
void Exti_Init_8_15(void)
{
	EXTI_InitTypeDef EXTI_InitStructure;
 	NVIC_InitTypeDef NVIC_InitStructure;
	//	GPIO��ʼ��
	Exti_8_15_GPIO_Init();	 
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);	//ʹ�ܸ��ù���ʱ��

	//  �ж����Լ��жϳ�ʼ������
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;	
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	if(IoInput_1_Enable)
	{
		//GPIOE.15
		GPIO_EXTILineConfig(GPIO_PortSourceGPIOE, GPIO_PinSource15);
		//�����ش��� EXTI_Trigger_Rising_Falling; ˫���ش���
		EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
		EXTI_InitStructure.EXTI_Line = EXTI_Line15;
		EXTI_Init(&EXTI_InitStructure);
	}
	if(IoInput_2_Enable)
	{
		//GPIOE.14
		GPIO_EXTILineConfig(GPIO_PortSourceGPIOE, GPIO_PinSource14);
		EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising; //�����ش���
		EXTI_InitStructure.EXTI_Line = EXTI_Line14;
		EXTI_Init(&EXTI_InitStructure);
	}
	if(IoInput_3_Enable)
	{
		//GPIOE.13
		GPIO_EXTILineConfig(GPIO_PortSourceGPIOE, GPIO_PinSource13);
		EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising; //�����ش���
		EXTI_InitStructure.EXTI_Line = EXTI_Line13;
		EXTI_Init(&EXTI_InitStructure);
	}
	if(IoInput_4_Enable)
	{
		//GPIOE.12
		GPIO_EXTILineConfig(GPIO_PortSourceGPIOE, GPIO_PinSource12);
		EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising; //�����ش���
		EXTI_InitStructure.EXTI_Line = EXTI_Line12;
		EXTI_Init(&EXTI_InitStructure);
	}
	if(IoInput_5_Enable)
	{
		//GPIOE.11
		GPIO_EXTILineConfig(GPIO_PortSourceGPIOE, GPIO_PinSource11);
		EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising; //�����ش���
		EXTI_InitStructure.EXTI_Line = EXTI_Line11;
		EXTI_Init(&EXTI_InitStructure);
	}
	if(IoInput_6_Enable)
	{
		//GPIOE.10
		GPIO_EXTILineConfig(GPIO_PortSourceGPIOE, GPIO_PinSource10);
		EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising; //�����ش���
		EXTI_InitStructure.EXTI_Line = EXTI_Line10;
		EXTI_Init(&EXTI_InitStructure);
	}
	if(IoInput_7_Enable)
	{
		//GPIOE.9
		GPIO_EXTILineConfig(GPIO_PortSourceGPIOE, GPIO_PinSource9);
		EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising; //�����ش���
		EXTI_InitStructure.EXTI_Line = EXTI_Line9;
		EXTI_Init(&EXTI_InitStructure);
	}
	if(IoInput_8_Enable)
	{
		//GPIOE.8
		GPIO_EXTILineConfig(GPIO_PortSourceGPIOE, GPIO_PinSource8);
		EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling; //˫���ش���
		EXTI_InitStructure.EXTI_Line = EXTI_Line8;
		EXTI_Init(&EXTI_InitStructure);
	}
	if(IoInput_1_Enable
		|| IoInput_2_Enable
		|| IoInput_3_Enable
		|| IoInput_4_Enable
		|| IoInput_5_Enable
		|| IoInput_6_Enable)
	{
		NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;		//�ж�����
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;	//��ռ���ȼ�
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;			//�����ȼ�
		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;				//ʹ���ⲿ�ж�ͨ��
		NVIC_Init(&NVIC_InitStructure);
	}
	if(IoInput_7_Enable
		|| IoInput_8_Enable)
	{
		NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;			//�ж�����
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;	//��ռ���ȼ�
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;			//�����ȼ�
		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;				//ʹ���ⲿ�ж�ͨ��
		NVIC_Init(&NVIC_InitStructure);
	}
}

//�ⲿ�ж�0������� 
void EXTI0_IRQHandler(void)
{
	EXTI_ClearITPendingBit(EXTI_Line0);   
}

//�ⲿ�ж�1������� 
void EXTI1_IRQHandler(void)
{
	EXTI_ClearITPendingBit(EXTI_Line1);   
}

//�ⲿ�ж�2������� 
void EXTI2_IRQHandler(void)
{
	EXTI_ClearITPendingBit(EXTI_Line2);   
}

//�ⲿ�ж�3������� 

void EXTI3_IRQHandler(void)
{
	EXTI_ClearITPendingBit(EXTI_Line3);   
}

//�ⲿ�ж�4������� 
void EXTI4_IRQHandler(void)
{
	EXTI_ClearITPendingBit(EXTI_Line4);   
}

void EXTI9_5_IRQHandler(void)
{	
	// XZ6 ��ת�� ��λ���  
	if (EXTI_GetITStatus(EXTI_Line7) != RESET)
	{
//		if(XZ6 == XZ6_Pass)
//		{
//			delay_us(50);
//			if(XZ6 == XZ6_Pass)
//			{
////				motorInfo_XZ.position = 0;
//////				motorInfo_XZ.inOrigin = true;
////				if(!motorRunParam_XZ.direction)
////					stepperMotorStop(Motor_XZ);
//			}
//		}
		EXTI_ClearITPendingBit(EXTI_Line7);//����жϱ�־λ
	}	
	
	//XEG
	if (EXTI_GetITStatus(EXTI_Line8) != RESET)
	{
//		if(XEG == XEG_ExistBox)
//		{
//			delay_us(50);
//			if(XEG == XEG_ExistBox)
//			{
//				motorInfo_Y.position = mpd.Y_end;
//				if(motorRunParam_Y.direction)
//				{
//					stepperMotorStop(Motor_Y);
//				}
//			}
//		}
		EXTI_ClearITPendingBit(EXTI_Line8);//����жϱ�־λ
	}	
	
	//ZHG
	if (EXTI_GetITStatus(EXTI_Line9) != RESET)
	{
//		if(ZHG == ZHG_ExistBox)
//		{
//			delay_us(50);
//			if(ZHG == ZHG_ExistBox)
//			{
//				motorInfo_Y.position = mpd.Y_end;
//				if(motorRunParam_Y.direction)
//				{
//					stepperMotorStop(Motor_Y);
//				}
//			}
//		}
		EXTI_ClearITPendingBit(EXTI_Line9);//����жϱ�־λ
	}	
}

void EXTI15_10_IRQHandler(void)
{	
		// G_QLE ����β������������
	if (EXTI_GetITStatus(EXTI_Line10) != RESET)
	{
		EXTI_ClearITPendingBit(EXTI_Line10);//����жϱ�־λ
	}	
	
	
	if (EXTI_GetITStatus(EXTI_Line11) != RESET)
	{
		if(YE == YE_Blocking)
			{
				delay_us(50);
				if(YE == YE_Blocking)
				{
					//stepperMotorStop(Motor_Y);
					motorInfo_Y.position = mpd.Y_end;
					if(motorRunParam_Y.direction)
					{
						stepperMotorStop(Motor_Y);
					}
				}
			}
		EXTI_ClearITPendingBit(EXTI_Line11);//����жϱ�־λ
	}	
	
	if (EXTI_GetITStatus(EXTI_Line12) != RESET)
	{
		// YH ������ ������
		if(YH == YH_Blocking)
		{
			delay_us(50);
			if(YH == YH_Blocking)
			{
				//stepperMotorStop(Motor_Y);
				motorInfo_Y.position = 0;
				if(!motorRunParam_Y.direction)
				{
					stepperMotorStop(Motor_Y);
				}
			}
		}
		EXTI_ClearITPendingBit(EXTI_Line12);//����жϱ�־λ
	}	
	// ��������
	if (EXTI_GetITStatus(EXTI_Line13) != RESET)
	{
		if(BUTTON == BUTTON_Press)
		{
			delay_us(50);
			if(BUTTON == BUTTON_Press)
			{
				while(BUTTON == BUTTON_Press);
				stepperMotorStop(Motor_X);
				stepperMotorStop(Motor_Y);
				deviceState.motorReset_runningState = RunningState_none;
				deviceState.motorReset_threadEnable = ON;	// ���������λ����
				deviceState.motorReset_runningState = RunningState_readyStart;	// ��������λ
			}
		}
		EXTI_ClearITPendingBit(EXTI_Line13);//����жϱ�־λ
	}
	// XE ������ �յ���
	if (EXTI_GetITStatus(EXTI_Line14) != RESET)
	{
			if(XE == XE_Blocking)
			{
				delay_us(50);
				if(XE == XE_Blocking)
				{
					//stepperMotorStop(Motor_X);
					motorInfo_X.position = mpd.X_end;
					if(motorRunParam_X.direction)
						stepperMotorStop(Motor_X);
				}
			}
		EXTI_ClearITPendingBit(EXTI_Line14);//����жϱ�־λ
	}
	if (EXTI_GetITStatus(EXTI_Line15) != RESET)
	{
		// XH ������ ������
		if(XH == XH_Blocking)
		{
			
			delay_us(50);
			if(XH == XH_Blocking)
			{
				//stepperMotorStop(Motor_X);
				motorInfo_X.position = 0;
				if(!motorRunParam_X.direction)
					stepperMotorStop(Motor_X);
			}
		}
		EXTI_ClearITPendingBit(EXTI_Line15);//����жϱ�־λ
	}
}
