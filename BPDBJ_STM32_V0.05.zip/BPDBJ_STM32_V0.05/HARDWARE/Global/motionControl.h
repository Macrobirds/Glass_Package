#ifndef __motionControl_h
#define __motionControl_h

#include <stm32f10x.h>
#include <stdbool.h>
bool check_deviceCanControl(void);
#endif
